## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
# # install.packages("pak")
# pak::pak("hadeda-r/hadeda")
# 
# library(hadeda)

## -----------------------------------------------------------------------------
# library(dplyr)

## -----------------------------------------------------------------------------
# mirror <- hadeda_config(
#   network = "testnet",
#   rest = list(
#     base_url = "https://testnet.hashio.io/api/v1",
#     headers = list(`X-API-Key` = Sys.getenv("HASHIO_API_KEY"))
#   ),
#   default_transport = "rest"
# )

## -----------------------------------------------------------------------------
# grpc_handler <- list(
#   operator_account_id = Sys.getenv("HADEDA_OPERATOR_ID"),
#   channel = function() {
#     stop("Configure a gRPC channel factory for your environment")
#   },
#   sign_transaction = function(tx_bytes) {
#     stop("Provide a signing routine that returns raw signature bytes")
#   }
# )
# 
# default <- hadeda_config(network = "testnet")
# default$grpc <- modifyList(default$grpc, grpc_handler)

## -----------------------------------------------------------------------------
# created <- crypto_create_account(
#   default,
#   public_key = Sys.getenv("HADEDA_PUBLIC_KEY"),
#   initial_balance = 10,
#   wait_for_record = TRUE
# )
# 
# created |> tidyr::unnest_wider(receipt)

