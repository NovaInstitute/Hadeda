## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
# mirror <- hadeda_config(network = "testnet", default_transport = "rest")
# 
# recent <- topics_messages(
#   mirror,
#   topic_id = "0.0.1234",
#   limit = 25,
#   order = "desc"
# )
# 
# recent |> dplyr::select(sequence_number, consensus_timestamp, message)

## -----------------------------------------------------------------------------
# topic <- topics_get(mirror, topic_id = "0.0.1234")
# 
# topic

## -----------------------------------------------------------------------------
# config <- hadeda_config(network = "testnet")
# config$grpc$submit_message <- function(config, topic_id, payload, memo, chunk_info, wait_for_receipt) {
#   stop("Replace with a gRPC client that returns Hedera receipt metadata")
# }
# 
# ack <- consensus_submit_message(
#   config,
#   topic_id = "0.0.1234",
#   message = "Hello, Hedera!",
#   memo = "hadeda vignette"
# )

