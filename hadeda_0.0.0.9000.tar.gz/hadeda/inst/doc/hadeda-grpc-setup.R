## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
# install_if_missing <- function(package, install_call) {
#   if (!requireNamespace(package, quietly = TRUE)) {
#     message(sprintf("Installing %s...", package))
#     eval(install_call)
#   }
# }
# 
# install_if_missing("pak", quote(install.packages("pak")))
# install_if_missing("credentials", quote(install.packages("credentials")))
# install_if_missing("remotes", quote(install.packages("remotes")))
# install_if_missing("jsonlite", quote(install.packages("jsonlite")))
# install_if_missing("RProtoBuf", quote(install.packages("RProtoBuf")))
# install_if_missing("here", quote(install.packages("here")))
# 
# if (requireNamespace("credentials", quietly = TRUE)) {
#   credentials::git_credential_ask()
# }
# 
# if (!requireNamespace("hadeda", quietly = TRUE)) {
#   remotes::install_github("NovaInstitute/Hadeda")
# }
# 
# if (!requireNamespace("grpc", quietly = TRUE)) {
#   remotes::install_github("christiaanpauw/grpc")
# }
# 
# if (requireNamespace("pak", quietly = TRUE)) {
#   pak::pak("openssl")
# } else {
#   install_if_missing("openssl", quote(install.packages("openssl")))
# }
# 
# library(hadeda)
# library(grpc)
# library(jsonlite)
# library(RProtoBuf)
# library(here)

## -----------------------------------------------------------------------------
# bundle_dest <- here::here("proto")
# if (!dir.exists(bundle_dest)) {
#   proto_root <- hadeda_grpc_use_proto_bundle(dest = bundle_dest, version = "0.47.0")
# } else {
#   proto_root <- normalizePath(bundle_dest)
#   message(sprintf("Using existing proto bundle at %s", proto_root))
# }
# list.files(proto_root, recursive = FALSE)

## -----------------------------------------------------------------------------
# needed <- c(
#   "services/crypto_service.proto",
#   "services/network_service.proto"
# )
# needed

## -----------------------------------------------------------------------------
# proto_paths <- c(proto_root, file.path(proto_root, "services"))
# options(
#   RProtoBuf.importPath = unique(c(getOption("RProtoBuf.importPath"), proto_paths))
# )
# 
# crypto_stubs <- grpc::read_services(file.path(proto_root, "services", "crypto_service.proto"))
# network_stubs <- grpc::read_services(file.path(proto_root, "services", "network_service.proto"))

## -----------------------------------------------------------------------------
# google_proto_path <- file.path(system2("brew", c("--prefix", "protobuf"), stdout = TRUE), "include")
# options(
#   RProtoBuf.importPath = unique(c(getOption("RProtoBuf.importPath"), google_proto_path))
# )

## -----------------------------------------------------------------------------
# channel_factory <- function(target = "testnet.hedera.com:50211") {
#   grpc::grpc_channel_create(target, opts = list("grpc.ssl_target_name_override" = "testnet.hedera.com"))
# }
# 
# crypto_service <- function(channel) {
#   grpc::grpc_client(crypto_stubs, channel)
# }
# 
# network_service <- function(channel) {
#   grpc::grpc_client(network_stubs, channel)
# }

## -----------------------------------------------------------------------------
# proto_message <- function(type) {
#   descriptor <- RProtoBuf::P(type)
#   function(...) {
#     do.call(RProtoBuf::new, c(list(descriptor), list(...)))
#   }
# }
# 
# to_account_id <- function(id) {
#   parts <- as.integer(strsplit(id, "\\.")[[1]])
#   list(shardNum = parts[1], realmNum = parts[2], accountNum = parts[3])
# }
# 
# now_timestamp <- function() {
#   instant <- as.integer(as.numeric(Sys.time()))
#   list(seconds = instant, nanos = 0L)
# }
# 
# crypto_get_account_info <- proto_message("proto.CryptoGetInfoQuery")
# query_wrapper <- proto_message("proto.Query")

## -----------------------------------------------------------------------------
# operator <- hadeda_grpc_env_credentials()
# sign_transaction <- hadeda_grpc_ed25519_signer()
# operator$public_key <- hadeda_grpc_signer_public_key(sign_transaction)

## -----------------------------------------------------------------------------
# crypto_cost_query <- function(account_id, channel = NULL) {
#   if (is.null(channel)) {
#     channel <- channel_factory()
#     on.exit(grpc::grpc_channel_destroy(channel), add = TRUE)
#   }
# 
#   client <- crypto_service(channel)
#   cost_query <- query_wrapper(
#     cryptogetinfo = crypto_get_account_info(
#       header = list(
#         responseType = "COST_ANSWER",
#         payment = list()
#       ),
#       accountID = to_account_id(account_id)
#     )
#   )
# 
#   response <- client$cryptoGetAccountInfo$call(cost_query)
#   as.list(response)
# }

## -----------------------------------------------------------------------------
# transaction_body <- proto_message("proto.TransactionBody")
# transaction <- proto_message("proto.Transaction")
# 
# build_payment <- function(operator, account_id, cost, valid_duration = 120L) {
#   pub_key <- hadeda_grpc_signer_public_key(sign_transaction)
#   body <- transaction_body(
#     transactionID = list(
#       accountID = to_account_id(operator$operator_account_id),
#       transactionValidStart = now_timestamp()
#     ),
#     nodeAccountID = to_account_id("0.0.3"),
#     transactionFee = cost,
#     transactionValidDuration = list(seconds = as.integer(valid_duration)),
#     cryptoTransfer = list(
#       transfers = list(
#         accountAmounts = list(
#           list(accountID = to_account_id(operator$operator_account_id), amount = -cost),
#           list(accountID = to_account_id("0.0.3"), amount = cost)
#         )
#       )
#     )
#   )
# 
#   body_bytes <- RProtoBuf::serialize(body, NULL)
#   sig_bytes <- sign_transaction(body_bytes)
#   signature_map <- list(
#     sigPair = list(
#       list(
#         pubKeyPrefix = pub_key,
#         ed25519 = sig_bytes
#       )
#     )
#   )
# 
#   signed_transaction <- transaction(
#     bodyBytes = body_bytes,
#     sigMap = signature_map
#   )
# 
#   RProtoBuf::serialize(signed_transaction, NULL)
# }

## -----------------------------------------------------------------------------
# query_account_info <- function(config, account_id) {
#   channel <- config$grpc$channel()
#   on.exit(grpc::grpc_channel_destroy(channel))
# 
#   cost_response <- crypto_cost_query(account_id, channel)
#   cost <- cost_response$cryptogetaccountinfo$responseHeader$cost
#   payment <- build_payment(config$grpc$operator, account_id, cost)
# 
#   query_message <- query_wrapper(
#     cryptogetinfo = crypto_get_account_info(
#       header = list(
#         responseType = "ANSWER_ONLY",
#         payment = list(signedTransactionBytes = payment)
#       ),
#       accountID = to_account_id(account_id)
#     )
#   )
# 
#   client <- crypto_service(channel)
#   response <- client$cryptoGetAccountInfo$call(query_message)
#   as.list(response)
# }

## -----------------------------------------------------------------------------
# grpc_handler <- list(
#   operator_account_id = operator$operator_account_id,
#   operator = operator,
#   channel = channel_factory,
#   sign_transaction = sign_transaction,
#   get_account_info = function(config, account_id) {
#     query_account_info(config, account_id)
#   }
# )
# 
# grpc_config <- hadeda_config(network = "testnet", default_transport = "grpc")
# grpc_config$grpc <- modifyList(grpc_config$grpc, grpc_handler)

## -----------------------------------------------------------------------------
# info <- crypto_account_info(grpc_config, operator$operator_account_id)
# info

