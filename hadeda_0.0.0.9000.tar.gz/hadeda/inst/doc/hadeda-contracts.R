## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
# config <- hadeda_config(network = "testnet", default_transport = "rest")
# 
# metadata <- contracts_get(config, contract_id = "0.0.6001")
# metadata
# 
# bytecode <- contracts_bytecode(config, contract_id = "0.0.6001")
# substring(bytecode$bytecode[[1]], 1, 16)

## -----------------------------------------------------------------------------
# config <- hadeda_config(network = "testnet")
# config$grpc$contract_deploy <- function(...) {
#   stop("Implement SmartContractService::createContract for your environment")
# }
# 
# deployed <- contract_deploy(
#   config,
#   bytecode = "6080604052348015600f57600080fd5b...",
#   gas = 2e6,
#   memo = "Example deployment",
#   wait_for_record = TRUE
# )
# 
# deployed |> tidyr::unnest_wider(receipt)

## -----------------------------------------------------------------------------
# config$grpc$contract_call <- function(...) {
#   stop("Implement SmartContractService::contractCallMethod")
# }
# 
# result <- contract_call(
#   config,
#   contract_id = deployed$contract_id[[1]],
#   function_signature = "balanceOf(address)",
#   parameters = list("0x0000000000000000000000000000000000000000"),
#   gas = 1e6,
#   wait_for_record = TRUE
# )
# 
# result$return_data

## -----------------------------------------------------------------------------
# info <- tokens_get(config, token_id = "0.0.4001")
# stopifnot(info$total_supply[[1]] == 1e6)

