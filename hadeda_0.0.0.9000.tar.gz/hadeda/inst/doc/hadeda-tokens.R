## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
# config <- hadeda_config(network = "testnet", default_transport = "rest")
# 
# info <- tokens_get(config, token_id = "0.0.4001")
# info |> tidyr::unnest_wider(custom_fees)

## -----------------------------------------------------------------------------
# balances <- tokens_balances(
#   config,
#   token_id = "0.0.4001",
#   limit = 50
# )
# 
# balances

## -----------------------------------------------------------------------------
# config <- hadeda_config(network = "testnet")
# config$grpc$token_create <- function(...) {
#   stop("Provide a TokenService::createToken implementation")
# }
# config$grpc$token_associate <- function(...) {
#   stop("Provide a TokenService::associateTokens implementation")
# }
# 
# created <- tokens_create(
#   config,
#   name = "Example Token",
#   symbol = "EXM",
#   treasury_account_id = "0.0.7001",
#   initial_supply = 1e6,
#   token_type = "fungible_common"
# )
# 
# association <- tokens_associate(
#   config,
#   account_id = "0.0.8002",
#   token_ids = c("0.0.4001", "0.0.5003"),
#   .transport = "grpc"
# )

## -----------------------------------------------------------------------------
# approvals <- accounts_allowances_tokens(
#   config,
#   account_id = "0.0.7001"
# )
# 
# approvals |> dplyr::count(spender, wt = amount)

