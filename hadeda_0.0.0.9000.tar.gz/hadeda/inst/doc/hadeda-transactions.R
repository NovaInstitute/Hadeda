## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = FALSE
)

## -----------------------------------------------------------------------------
# config <- hadeda_config(network = "testnet", default_transport = "rest")
# 
# transfers <- transactions_list(
#   config,
#   account_id = "0.0.1001",
#   transaction_type = "CRYPTOTRANSFER",
#   order = "desc",
#   limit = 10
# )
# 
# transfers |> dplyr::select(consensus_timestamp, name, result, charged_tx_fee)

## -----------------------------------------------------------------------------
# detail <- transactions_get(
#   config,
#   transaction_id = transfers$transaction_id[[1]],
#   limit = 20
# )
# 
# detail |> tidyr::unnest(records)

## -----------------------------------------------------------------------------
# record <- crypto_transaction_record(
#   hadeda_config(network = "testnet"),
#   transaction_id = "0.0.5005-1700000000-000000000",
#   include_duplicates = TRUE,
#   include_child_records = TRUE
# )
# 
# record$duplicate_records[[1]]
# record$child_records[[1]]

## -----------------------------------------------------------------------------
# config <- hadeda_config(network = "testnet")
# config$grpc$transfer <- function(config, transfers, token_transfers, memo, transaction_valid_duration, max_fee, wait_for_receipt) {
#   stop("Provide a CryptoService transfer handler")
# }
# 
# xfer <- crypto_transfer(
#   config,
#   transfers = tibble::tibble(
#     account_id = c("0.0.1001", "0.0.2002"),
#     amount = c(-1000L, 1000L)
#   ),
#   memo = "Example transfer"
# )

## -----------------------------------------------------------------------------
# net <- transfers |>
#   dplyr::mutate(amount = purrr::map_dbl(transfers, ~sum(purrr::map_dbl(.x$transfers, "amount")))) |>
#   dplyr::arrange(consensus_timestamp)
# 
# net

